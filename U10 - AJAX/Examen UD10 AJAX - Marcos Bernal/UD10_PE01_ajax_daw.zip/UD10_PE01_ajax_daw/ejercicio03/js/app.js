// RUTA AL ARCHIVO JSON
const URL_JSON = "";

// CONTENEDOR HTML
const contenedor = document.getElementById("productos");

// BOTONES



/* =====================================================
   FUNCIÓN PRINCIPAL – ACTUALIZACIÓN DINÁMICA
   ===================================================== */
function cargarProductos() {

    // c) Limpiar contenido anterior
    contenedor.innerHTML = "";

    // a) Petición AJAX (Fetch) o b) mediante objeto XMLHttpRequest
    

}




/* =====================================================
   FUNCIÓN AUXILIAR PARA MOSTRAR PRODUCTOS
   ===================================================== */
function mostrarProducto(producto) {
  
}
