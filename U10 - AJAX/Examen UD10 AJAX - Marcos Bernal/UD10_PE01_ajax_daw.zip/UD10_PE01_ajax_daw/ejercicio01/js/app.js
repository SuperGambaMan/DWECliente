// RUTA AL ARCHIVO JSON
const URL_JSON = "";

// CONTENEDOR HTML
const contenedor = document.getElementById("productos");

// BOTONES


/* =====================================================
   FUNCIÓN 1: CARGAR PRODUCTOS CON XMLHttpRequest
   ===================================================== */
function cargarConXHR() {
  // Limpiar contenido anterior
  contenedor.innerHTML = "";

  // TODO: Crear el objeto XMLHttpRequest
  // TODO: Configurar la petición GET
  // TODO: Gestionar readyState y status
  // TODO: Convertir la respuesta a objeto JavaScript
  // TODO: Mostrar los productos en pantalla
}



/* =====================================================
   FUNCIÓN AUXILIAR PARA MOSTRAR PRODUCTOS
   ===================================================== */
function mostrarProducto(producto) {
  
}
