// RUTA AL ARCHIVO JSON
const URL_JSON = "";

// CONTENEDOR HTML
const contenedor = document.getElementById("productos");

// BOTONES




/* =====================================================
   FUNCIÓN 2: CARGAR PRODUCTOS CON FETCH
   ===================================================== */
function cargarConFetch() {
  // Limpiar contenido anterior
  contenedor.innerHTML = "";

  // TODO: Realizar la petición usando fetch
  // TODO: Convertir la respuesta a JSON
  // TODO: Recorrer el array de productos
  // TODO: Mostrar los productos usando Bootstrap
}


/* =====================================================
   FUNCIÓN AUXILIAR PARA MOSTRAR PRODUCTOS
   ===================================================== */
function mostrarProducto(producto) {
  
}
