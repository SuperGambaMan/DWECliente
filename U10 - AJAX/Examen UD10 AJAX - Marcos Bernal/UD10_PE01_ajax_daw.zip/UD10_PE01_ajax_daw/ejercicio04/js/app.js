// RUTA AL ARCHIVO JSON
const URL_JSON = "";

// CONTENEDOR HTML
const contenedor = document.getElementById("productos");

// BOTONES


/* =====================================================
   FUNCIÓN 1: CARGAR PRODUCTOS CON XMLHttpRequest
   ===================================================== */
function cargarConXHR() {
  // Limpiar contenido anterior
  contenedor.innerHTML = "";

  // TODO: Crear el objeto XMLHttpRequest
  // TODO: Configurar la petición GET
  // TODO: Gestionar readyState y status
  // TODO: Convertir la respuesta a objeto JavaScript
  // TODO: Mostrar los productos en pantalla
}

/* =====================================================
   FUNCIÓN 2: CARGAR PRODUCTOS CON FETCH
   ===================================================== */
function cargarConFetch() {
  // Limpiar contenido anterior
  contenedor.innerHTML = "";

  // TODO: Realizar la petición usando fetch
  // TODO: Convertir la respuesta a JSON
  // TODO: Recorrer el array de productos
  // TODO: Mostrar los productos usando Bootstrap
}

/* =====================================================
   FUNCIÓN 3: FILTRAR PRODUCTO POR ID (SIMULANDO GET)
   ===================================================== */
function filtrarProducto() {
  // Limpiar contenido anterior
  contenedor.innerHTML = "";

  const idProducto = 2; // Simulación de parámetro GET

  // TODO: Cargar el JSON
  // TODO: Buscar el producto con el ID indicado
  // TODO: Mostrar SOLO ese producto
}

/* =====================================================
   FUNCIÓN AUXILIAR PARA MOSTRAR PRODUCTOS
   ===================================================== */
function mostrarProducto(producto) {
  
}
